int main()
{
	int* test = nullptr;
	return test ? 1 : 0;
}
